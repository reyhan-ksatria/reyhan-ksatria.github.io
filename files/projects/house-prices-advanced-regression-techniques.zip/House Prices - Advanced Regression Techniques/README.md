# House Prices - Advanced Regression Techniques

Notebook ini membahas alur lengkap proyek machine learning untuk memprediksi harga jual rumah di Ames, Iowa, sebagai bagian dari kompetisi Kaggle House Prices - Advanced Regression Techniques. Alur mencakup pengecekan kualitas data, eksplorasi data, pembersihan data, feature engineering, perbandingan 8 algoritma regresi, hyperparameter tuning, ensemble model, interpretasi menggunakan SHAP, eksperimen feature selection, hingga menghasilkan file submission siap unggah.

## Tingkat Kesulitan

```
Kompleksitas Data: 6/10
Kompleksitas Modeling: 8/10
Kompleksitas Kode: 7/10
Kedalaman Konsep: 7/10
Overall: 7/10 (Intermediate)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model final | Ensemble HuberRegressor (bobot 0.796) dan NGBoost (bobot 0.204) |
| Val RMSE (skala log SalePrice) | 0.1098 |
| R² (skala dolar) | 0.9213 |
| MAE (skala dolar) | $14.148,74 |
| Jumlah fitur final | 73 (hasil seleksi dari 160 fitur setelah encoding) |
| Jumlah algoritma dibandingkan | 8 model + baseline DummyRegressor |

## Struktur Folder

```
House Prices - Advanced Regression Techniques/
├── checkpoints/
│   ├── baseline_model_comparison.joblib
│   ├── feature_selection_experiment_lanjutan.joblib
│   ├── feature_selection_experiment.joblib
│   ├── tuning_histgb.joblib
│   ├── tuning_huber.joblib
│   ├── tuning_lgbm.joblib
│   ├── tuning_ngboost.joblib
│   ├── tuning_quantile.joblib
│   └── tuning_rf.joblib
├── House Prices Dataset/
│   ├── data_description.txt
│   ├── sample_submission.csv
│   ├── test.csv
│   └── train.csv
├── images/
│   ├── boxplot_outlier_check.png
│   ├── distribusi_saleprice.png
│   ├── evaluasi_model_final.png
│   ├── fitur_kategorikal_vs_saleprice.png
│   ├── fitur_numerik_vs_saleprice.png
│   ├── heatmap_korelasi.png
│   ├── sanity_check_prediksi.png
│   ├── shap_bar_chart_top20.png
│   └── shap_summary_huber.png
├── House Prices Notebook.ipynb
├── README.md
└── submission.csv
```

## Tools dan Library

- pandas, numpy
- matplotlib, seaborn
- scikit-learn (Pipeline, StandardScaler, train_test_split, KFold, HuberRegressor, QuantileRegressor, BayesianRidge, KernelRidge, RandomForestRegressor, HistGradientBoostingRegressor, DummyRegressor, DecisionTreeRegressor)
- ngboost
- lightgbm
- optuna
- shap
- statsmodels (variance_inflation_factor)
- scipy (optimize, resample)
- joblib
- tqdm

## Cara Menjalankan

1. Pastikan seluruh library pada daftar Tools dan Library sudah terinstal. Beberapa library seperti ngboost, lightgbm, dan optuna diinstal langsung di dalam notebook lewat cell khusus, tidak perlu instalasi manual terpisah.
2. Buka House Prices Notebook.ipynb, jalankan seluruh cell secara berurutan dari atas menggunakan Run All.
3. Beberapa proses seperti perbandingan model baseline dan hyperparameter tuning memakan waktu cukup lama pada percobaan pertama, namun hasilnya otomatis tersimpan sebagai checkpoint di folder checkpoints. Menjalankan ulang notebook setelahnya akan memuat hasil dari checkpoint tersebut sehingga jauh lebih cepat, tanpa perlu melatih ulang dari nol.
4. File submission.csv akan otomatis terbentuk di root folder setelah seluruh cell selesai dijalankan, siap diunggah ke halaman kompetisi Kaggle.

## Alur Kerja

**1. Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan, membuat folder untuk menyimpan visualisasi dan checkpoint, serta memuat data train dan test

**2. Data Quality Check** - memeriksa duplikat, tipe data, missing value, outlier, dan konsistensi nilai kategorikal

**3. Eksplorasi Data (EDA)** - memahami distribusi target dan hubungan setiap fitur terhadap SalePrice

**4. Split Data untuk Training dan Validasi** - memisahkan data sebelum pembersihan dilakukan untuk mencegah kebocoran data

**5. Data Cleaning** - menangani missing value dan outlier berdasarkan temuan Data Quality Check

**6. Feature Engineering** - membuat fitur turunan berdasarkan pola dari EDA

**7. Seleksi dan Encoding Fitur** - menggabungkan kategori langka, ordinal encoding, target encoding, dan one-hot encoding

**8. Modeling** - membandingkan 8 algoritma regresi yang beragam karakternya

**9. Hyperparameter Tuning** - mengoptimalkan parameter menggunakan Optuna

**10. Ensemble Model** - menggabungkan model terbaik dengan bobot yang dicari sistematis

**11. Evaluasi Model** - memeriksa scatter plot prediksi dan residual plot

**12. Interpretasi Model dengan SHAP** - menganalisis kontribusi setiap fitur terhadap prediksi

**13. Eksperimen Feature Selection** - menguji beberapa threshold kontribusi SHAP

**14. Retrain Model Final** - melatih ulang model terbaik pada seluruh data

**15. Prediksi Final dan Submission** - menghasilkan file submission

**16. Pengujian Multi-Seed** - memeriksa stabilitas ensemble terhadap variasi random state

**17. Kesimpulan** - merangkum model final, skor metrik, dan temuan penting

Tahap Cek dan Uji Class Imbalance dilewati karena tidak relevan untuk kasus regresi.

## Temuan Utama

Kualitas material dan luas area hidup rumah (OverallQual dan GrLivArea) tercatat sebagai dua faktor paling berpengaruh terhadap harga jual, konsisten dengan deskripsi resmi kompetisi. Log-transform pada target berhasil menurunkan skewness dari 1.8829 menjadi 0.1213, sementara target encoding pada Neighborhood berhasil mempertahankan sinyal lokasi yang kuat tanpa perlu puluhan kolom one-hot. Ensemble antara HuberRegressor dan NGBoost terbukti signifikan mengungguli model tunggal terbaik lewat pengujian bootstrap, dan eksperimen feature selection berbasis kontribusi SHAP berhasil menyederhanakan model dari 160 menjadi 73 fitur sekaligus memperbaiki performa validasi. Notebook ini juga mengungkap dan berhasil mengatasi kendala reproducibility pada NGBoost, yang ternyata tidak sepenuhnya deterministic akibat base learner default yang tidak otomatis ikut ter-seed oleh parameter random_state.

## Catatan

Nilai SalePrice sesungguhnya pada data test tidak diketahui karena disembunyikan oleh pihak Kaggle, sehingga val_rmse sebesar 0.1098 pada notebook ini adalah estimasi terbaik berdasarkan data validasi, bukan skor resmi di leaderboard kompetisi. Model final juga menunjukkan keterbatasan dalam memprediksi kombinasi fitur ekstrem yang jarang muncul di data training, seperti rumah berkualitas dan berukuran sangat besar namun berlokasi di lingkungan dengan harga menengah-bawah.

## Sumber Data

Dataset Ames Housing disusun oleh Dean De Cock, diakses melalui kompetisi Kaggle House Prices - Advanced Regression Techniques di https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques.