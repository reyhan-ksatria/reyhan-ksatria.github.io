# Deteksi Fraud Kartu Kredit Menggunakan Ensemble Deep Learning dan Gradient Boosting

Project ini membangun model deteksi fraud pada transaksi kartu kredit menggunakan dataset Credit Card Fraud Detection dari Machine Learning Group Université Libre de Bruxelles (ULB) dan Worldline, mencakup 284.807 transaksi dengan hanya 492 di antaranya berlabel fraud atau 0.172%. Notebook ini menekankan penanganan class imbalance yang sangat ekstrem tanpa teknik eksplisit seperti class_weight atau SMOTE, feature engineering berbasis fitur interaksi, perbandingan tujuh algoritma dengan karakteristik berbeda, hyperparameter tuning menggunakan Optuna, ensemble model melalui pencarian menyeluruh 127 kombinasi, interpretasi menggunakan SHAP, hingga eksperimen feature selection dan retrain model final.

## Tingkat Kesulitan

```
Kompleksitas Data: 9/10
Kompleksitas Modeling: 9/10
Kompleksitas Kode: 9/10
Kedalaman Konsep: 9/10
Overall: 9/10 (Advanced)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model Final | Soft Voting Ensemble (DNN + XGBoost) |
| Bobot Ensemble | 0.3634 (DNN) dan 0.6366 (XGBoost) |
| Threshold Ensemble | 0.50 |
| Accuracy Ensemble | 1.00 |
| Precision Kelas Fraud | 0.97 |
| Recall Kelas Fraud | 0.78 |
| F1-Score Kelas Fraud | 0.8636 |
| False Positive dari 56.864 Transaksi Normal | 2 |
| False Negative dari 98 Transaksi Fraud | 22 |
| Jumlah Model yang Dibandingkan | 7 |
| Jumlah Kombinasi Ensemble yang Diuji | 127 |
| Jumlah Fitur DNN | 37 |
| Jumlah Fitur XGBoost | 39 |
| Fitur Interaksi yang Dipertahankan | 6 dari 10 kandidat |
| Metode Tuning | Optuna dengan TPESampler |

## Struktur Folder

```
CREDIT CARD FRAUD DETECTION/
├── checkpoints/
│   ├── dcn_best_optuna_params.joblib
│   ├── dcn_best_optuna_trial_info.joblib
│   ├── dcn_history.pkl
│   ├── dcn_model.keras
│   ├── dcn_tuned_history.pkl
│   ├── dcn_tuned_model.keras
│   ├── dcn_tuned_threshold.joblib
│   ├── dnn_best_optuna_params.joblib
│   ├── dnn_best_optuna_trial_info.joblib
│   ├── dnn_history.pkl
│   ├── dnn_model.keras
│   ├── dnn_tuned_history.pkl
│   ├── dnn_tuned_model.keras
│   ├── dnn_tuned_threshold.joblib
│   ├── feature_selection_results.pkl
│   ├── final_dnn_model.keras
│   ├── final_xgb_model.pkl
│   ├── random_forest_best_optuna_params.joblib
│   ├── random_forest_best_optuna_trial_info.joblib
│   ├── random_forest_cv_scores.pkl
│   ├── random_forest_model.pkl
│   ├── random_forest_tuned_model.pkl
│   ├── random_forest_tuned_threshold.joblib
│   ├── residual_mlp_best_optuna_params.joblib
│   ├── residual_mlp_best_optuna_trial_info.joblib
│   ├── residual_mlp_history.pkl
│   ├── residual_mlp_model.keras
│   ├── residual_mlp_tuned_history.pkl
│   ├── residual_mlp_tuned_model.keras
│   ├── residual_mlp_tuned_threshold.joblib
│   ├── snn_best_optuna_params.joblib
│   ├── snn_best_optuna_trial_info.joblib
│   ├── snn_history.pkl
│   ├── snn_model.keras
│   ├── snn_tuned_history.pkl
│   ├── snn_tuned_model.keras
│   ├── snn_tuned_threshold.joblib
│   ├── voting_results.pkl
│   ├── wdn_best_optuna_params.joblib
│   ├── wdn_best_optuna_trial_info.joblib
│   ├── wdn_history.pkl
│   ├── wdn_model.keras
│   ├── wdn_tuned_history.pkl
│   ├── wdn_tuned_model.keras
│   ├── wdn_tuned_threshold.joblib
│   ├── xgboost_best_optuna_params.joblib
│   ├── xgboost_best_optuna_trial_info.joblib
│   ├── xgboost_cv_scores.pkl
│   ├── xgboost_model.pkl
│   ├── xgboost_tuned_model.pkl
│   └── xgboost_tuned_threshold.joblib
├── Credit Card Fraud Dataset/
│   └── creditcard.csv
├── images/
│   ├── amount_by_class.png
│   ├── boxplot_amount.png
│   ├── boxplot_v_features.png
│   ├── distribusi_class.png
│   ├── fraud_rate_by_hour.png
│   ├── heatmap_korelasi_interaksi.png
│   ├── heatmap_korelasi.png
│   ├── histogram_time.png
│   ├── learning_curve_dcn_tuned.png
│   ├── learning_curve_dcn.png
│   ├── learning_curve_dnn_tuned.png
│   ├── learning_curve_dnn.png
│   ├── learning_curve_residual_mlp_tuned.png
│   ├── learning_curve_residual_mlp.png
│   ├── learning_curve_snn_tuned.png
│   ├── learning_curve_snn.png
│   ├── learning_curve_wdn_tuned.png
│   ├── learning_curve_wdn.png
│   ├── pr_curve_confusion_matrix_ensemble.png
│   ├── shap_summary_dnn.png
│   ├── shap_summary_xgboost.png
│   ├── time_by_class.png
│   └── violinplot_top_features.png
├── Credit Card Fraud Notebook.ipynb
└── README.md
```

## Tools dan Library

- pandas, numpy — manipulasi dan analisis data
- matplotlib, seaborn — visualisasi
- tensorflow, keras — pembangunan dan training lima arsitektur neural network
- scikit-learn — split data, VIF, metrics evaluasi, model tree-based
- xgboost — model gradient boosting
- optuna — hyperparameter tuning dengan TPESampler
- shap — interpretasi model berbasis DeepExplainer dan TreeExplainer
- joblib, pickle — penyimpanan checkpoint model dan hasil eksperimen
- tqdm — progress bar

## Cara Menjalankan

1. Pastikan Python 3.10 atau lebih baru sudah terinstall di environment Anda
2. Buka `Credit Card Fraud Notebook.ipynb` menggunakan Jupyter Notebook, JupyterLab, atau VS Code
3. Jalankan seluruh cell secara berurutan dari atas ke bawah menggunakan Run All, atau satu per satu untuk mengikuti alur kerja secara bertahap
4. Beberapa cell akan otomatis menginstall package tambahan yang dibutuhkan (tensorflow, xgboost, optuna, shap)
5. Proses training ketujuh model baseline, hyperparameter tuning, pencarian kombinasi ensemble, eksperimen feature selection, dan retrain model final menggunakan checkpoint yang tersimpan di folder `checkpoints/`, sehingga menjalankan ulang notebook tidak akan mengulang proses yang memakan waktu lama. Hapus file checkpoint terkait jika ingin menjalankan ulang proses tersebut dari awal
6. Seluruh visualisasi akan tersimpan otomatis ke folder `images/`

## Alur Kerja

1. **Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan, mengunci seed di seluruh level untuk reproducibility, membuat folder untuk menyimpan visualisasi dan checkpoint, serta memuat dataset transaksi kartu kredit

2. **Data Quality Check** - memeriksa duplikat baris dan outlier pada kolom Amount menggunakan boxplot dan metode IQR

3. **Eksplorasi Data (EDA)** - memahami distribusi target, korelasi antar fitur, hubungan fitur terhadap target, serta pola Amount dan Time terhadap fraud

4. **Split Data untuk Training dan Validasi** - membagi data secara stratified menjadi data training dan validasi sebelum masuk ke tahap Data Cleaning, untuk mencegah kebocoran data

5. **Data Cleaning** - menghapus baris duplikat yang terbukti technical duplicate, melakukan scaling pada Amount dan Time khusus untuk kebutuhan model neural network, serta memverifikasi proporsi outlier Amount antara kelas fraud dan normal

6. **Feature Engineering** - menguji korelasi fitur turunan hour_of_day terhadap target, serta membangun fitur interaksi dari pasangan fitur dengan korelasi terkuat terhadap Class

7. **Seleksi dan Encoding Fitur** - mendeteksi redundansi antar fitur interaksi menggunakan Variance Inflation Factor (VIF), kemudian menghapus fitur yang melebihi ambang batas multikolinearitas

8. **Modeling** - melatih baseline DummyClassifier sebagai pembanding, dilanjutkan tujuh model dengan karakteristik berbeda yaitu Deep Neural Network (DNN), Residual MLP, Deep and Cross Network (DCN), Self-Normalizing Neural Network (SNN), Wide and Deep Network (WDN), Random Forest, dan XGBoost

9. **Hyperparameter Tuning** - ketujuh model di-tuning menggunakan Optuna, dengan objective F1-score kelas fraud dan pencarian threshold optimal pada setiap trial

10. **Ensemble Model** - menguji soft voting secara menyeluruh pada seluruh 127 kombinasi non-kosong dari ketujuh model, dengan bobot dicari menggunakan random search berbasis distribusi Dirichlet

11. **Evaluasi Model** - mengevaluasi kombinasi ensemble terbaik menggunakan classification report, confusion matrix, dan precision-recall curve

12. **Interpretasi Model** - dua komponen ensemble diinterpretasi menggunakan SHAP, DeepExplainer untuk DNN dan TreeExplainer untuk XGBoost, kemudian menggabungkan kedua skor kontribusi menjadi satu skor gabungan

13. **Eksperimen Feature Selection** - menguji beberapa ambang batas skor gabungan untuk melihat apakah menghapus fitur berkontribusi kecil dapat mempertahankan performa ensemble

14. **Retrain Model Final** - melatih ulang model final menggunakan gabungan seluruh data training dan validasi, tanpa menghitung ulang metrik evaluasi apapun

15. **Kesimpulan** - merangkum model final, skor metrik utama, fitur paling berpengaruh, temuan penting sepanjang notebook, kendala teknis yang sempat terjadi beserta cara mengatasinya, catatan keterbatasan, dan latihan untuk pembaca

## Temuan Utama

Seluruh tujuh model berhasil dilatih tanpa penanganan class imbalance eksplisit seperti class_weight atau SMOTE, membuktikan bahwa fitur-fitur yang tersedia, khususnya fitur interaksi hasil Feature Engineering, sudah cukup terpisah secara alami untuk data yang imbalance-nya sangat ekstrem sekalipun. Fitur interaksi ternyata memiliki korelasi jauh lebih kuat terhadap Class dibanding fitur individual manapun, dengan korelasi tertinggi ditunjukkan V14_V12_interaction sebesar 0.5809, jauh melampaui fitur individual terkuat yaitu V17 sebesar 0.3160. Pencarian menyeluruh terhadap 127 kombinasi soft voting menunjukkan kombinasi dua model DNN dan XGBoost mengungguli seluruh kombinasi lain termasuk ensemble penuh tujuh model, mencapai F1-score kelas fraud sebesar 0.8636. Interpretasi menggunakan SHAP menunjukkan V4 sebagai fitur individual paling berpengaruh secara konsisten pada DNN maupun XGBoost, dengan dua dari lima fitur teratas pada skor gabungan merupakan fitur interaksi buatan, bukan fitur asli dari dataset. Eksperimen feature selection membuktikan bahwa mempertahankan seluruh fitur tetap menghasilkan performa terbaik dibanding menghapus fitur berkontribusi kecil pada ambang batas manapun yang diuji.

## Catatan

Dataset ini tidak menyediakan data test terpisah yang independen sejak awal, hanya train dan validasi, sehingga data validasi digunakan berulang kali sepanjang tahap hyperparameter tuning, pencarian bobot ensemble, dan eksperimen feature selection, berisiko membuat estimasi performa akhir sedikit lebih optimis dibanding performa sesungguhnya pada data yang benar-benar baru. Pencarian bobot dan threshold pada tahap Ensemble Model secara khusus dilakukan langsung berdasarkan performa pada data validasi tanpa lapisan cross-validation tambahan, sehingga risiko penyesuaian berlebih terhadap pola spesifik data validasi tersebut relatif lebih besar dibanding tahap hyperparameter tuning yang sebagian modelnya menggunakan validasi silang. Model final berupa ensemble dua algoritma dengan mekanisme yang sangat berbeda, yaitu DNN dan XGBoost, sehingga interpretasi menggunakan SHAP harus dilakukan terpisah untuk masing-masing komponen dan tidak dapat digabungkan menjadi satu penjelasan tunggal yang utuh untuk keseluruhan ensemble.

## Sumber Data

Dataset yang digunakan adalah Credit Card Fraud Detection, hasil kolaborasi riset Worldline dan Machine Learning Group Université Libre de Bruxelles (ULB), tersedia di Kaggle pada https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud, dengan lisensi Database Open Database License (ODbL) dan Contents Open Database License. Dataset berisi transaksi kartu kredit nasabah Eropa selama dua hari pada bulan September 2013, dengan fitur V1 sampai V28 merupakan hasil transformasi PCA yang telah dianonimkan.