# Klasifikasi Apel dan Tomat menggunakan Transfer Learning

Notebook ini membahas alur lengkap proyek machine learning untuk membedakan gambar apel dan tomat, dua buah yang sengaja dipilih karena kemiripan visualnya membuat klasifikasi ini cukup menantang. Dataset berisi 391 gambar hasil web scraping, terbagi ke folder train dan test dengan ukuran gambar bervariasi antara 100 hingga 335 piksel. Alur mencakup pengecekan kualitas data, deteksi dan pembersihan duplikat, eksplorasi data, ekstraksi fitur menggunakan backbone EfficientNetB0 yang dibekukan, reduksi dimensi dengan PCA, hyperparameter tuning dengan objective khusus untuk menekan gap train-val, hingga interpretasi menggunakan Grad-CAM.

## Tingkat Kesulitan

```
Kompleksitas Data: 5/10
Kompleksitas Modeling: 7/10
Kompleksitas Kode: 7/10
Kedalaman Konsep: 7/10
Overall: 6.5/10 (Intermediate)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model final | Classifier head dengan units: 8, dropout_rate: 0.4, l2_rate: 0.5, dan learning_rate: 0.001, dibangun di atas fitur EfficientNetB0 yang direduksi PCA ke 58 dimensi, dilatih dari gabungan 281 gambar train-fit dan validasi |
| Val accuracy (model tuned, sebelum retrain) | 0.9583 |
| Test accuracy (model final) | 0.9381 |
| Precision, recall, F1-score (apples) | 0.91, 0.98, 0.95 |
| Precision, recall, F1-score (tomatoes) | 0.97, 0.88, 0.93 |
| Dimensi fitur (sebelum → sesudah PCA) | 1.280 → 58 |
| Gap train-val (sebelum → sesudah tuning) | 0.0388 → 0.0244 |

## Struktur Folder

```
Apples or Tomatoes - Image Classification/
├── Apples or Tomatoes Dataset/
│   ├── test/
│   │   ├── apples/
│   │   └── tomatoes/
│   └── train/
│       ├── apples/
│       └── tomatoes/
├── checkpoints/
│   ├── tuning_classifier_head/
│   ├── best_classifier_head_tuned.keras
│   ├── best_classifier_head.keras
│   ├── best_hyperparameters.joblib
│   ├── features_test.joblib
│   ├── features_train_fit.joblib
│   ├── features_val.joblib
│   ├── final_features.joblib
│   ├── final_model_history.pkl
│   ├── final_model.keras
│   ├── history_classifier_head_tuned.pkl
│   ├── history_classifier_head.pkl
│   └── pca_transformer.joblib
├── images/
│   ├── confusion_matrix_test_final.png
│   ├── confusion_matrix_test.png
│   ├── confusion_matrix_val.png
│   ├── distribusi_kelas.png
│   ├── gradcam_visualization.png
│   ├── learning_curve_after_tuning.png
│   ├── learning_curve_before_tuning.png
│   ├── learning_curve_final.png
│   ├── sample_gambar.png
│   ├── scan_apples.png
│   └── scan_tomatoes.png
├── Apples or Tomatoes Notebook.ipynb
└── README.md
```

## Tools dan Library

- pandas, numpy
- matplotlib, seaborn
- tensorflow (Keras, layers, models, callbacks)
- scikit-learn (GroupShuffleSplit, PCA, DummyClassifier, confusion_matrix, classification_report)
- keras-tuner (RandomSearch)
- PIL (Image, ImageEnhance)
- joblib, pickle, hashlib, os

## Cara Menjalankan

1. Pastikan library pada daftar Tools dan Library sudah terinstal. Instalasi tensorflow dan keras-tuner dilakukan otomatis lewat cell khusus di awal dan di bagian Hyperparameter Tuning, tidak perlu instalasi manual terpisah.
2. Buka Apples or Tomatoes Notebook.ipynb, jalankan seluruh cell secara berurutan dari atas menggunakan Run All.
3. Ekstraksi fitur, hyperparameter tuning, dan training classifier head memakan waktu cukup lama pada percobaan pertama, namun hasilnya otomatis tersimpan sebagai checkpoint di folder checkpoints. Menjalankan ulang notebook setelahnya akan memuat hasil dari checkpoint tersebut sehingga jauh lebih cepat, tanpa perlu melatih ulang dari nol. Checkpoint yang sudah ada sebaiknya tidak dihapus, supaya hasil yang dilaporkan di notebook tetap konsisten setiap kali dijalankan ulang.
4. Seluruh evaluasi akhir, termasuk confusion matrix dan classification report pada data test, otomatis ditampilkan di bagian akhir notebook setelah seluruh cell selesai dijalankan.

## Alur Kerja

**1. Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan, mengunci seluruh sumber random, membuat folder untuk menyimpan visualisasi dan checkpoint, serta memuat dataset

**2. Data Quality Check** - memeriksa file korup, mode warna, dan statistik ukuran gambar pada seluruh dataset

**3. Deteksi dan Pembersihan Duplikat** - menghitung hash MD5 tiap gambar untuk menemukan duplikat, termasuk duplikat lintas train-test dan gambar dengan label kontradiktif

**4. Distribusi Kelas dan Class Weight** - memeriksa rasio imbalance antar kelas untuk menentukan perlu tidaknya class_weight pada tahap modeling

**5. Eksplorasi Visual** - menampilkan sample gambar tiap kelas untuk memahami karakteristik dan variasi visual dataset

**6. Split Data Train-Fit dan Validasi** - membagi data train menggunakan GroupShuffleSplit berdasarkan hash gambar, mencegah duplikat terpisah ke subset berbeda

**7. Preprocessing Gambar** - menyiapkan fungsi untuk memuat, resize, dan preprocess gambar sesuai kebutuhan input EfficientNetB0

**8. Ekstraksi Fitur dengan EfficientNetB0** - mengekstrak fitur dari backbone EfficientNetB0 yang dibekukan, dilengkapi augmentasi lima variasi pada data train-fit

**9. Reduksi Dimensi dengan PCA** - memangkas dimensi fitur menggunakan PCA yang di-fit hanya dari data train-fit untuk mencegah data leakage

**10. Baseline DummyClassifier** - melatih baseline sederhana sebagai titik pembanding minimum

**11. Classifier Head sebelum Tuning** - melatih classifier head dengan hyperparameter awal, dilengkapi learning curve dan pengecekan gap train-val

**12. Hyperparameter Tuning** - mencari kombinasi hyperparameter terbaik menggunakan Keras Tuner dengan objective khusus meminimalkan gap train-val secara langsung

**13. Classifier Head sesudah Tuning** - melatih ulang classifier head menggunakan hyperparameter terbaik hasil tuning

**14. Evaluasi Model pada Data Validasi** - memeriksa confusion matrix dan classification report model tuned pada data validasi

**15. Evaluasi Model pada Data Test** - mengukur performa model tuned pada data test yang belum pernah dilihat sepanjang training maupun tuning

**16. Interpretasi Model dengan Grad-CAM** - memvisualisasikan area gambar yang paling memengaruhi keputusan model

**17. Retrain Model Final** - melatih ulang model menggunakan gabungan seluruh data train-fit dan validasi

**18. Prediksi Final** - mengevaluasi model final pada data test sebagai hasil akhir yang dilaporkan

**19. Kesimpulan** - merangkum model final, performa, dan temuan penting sepanjang notebook

## Temuan Utama

Reduksi dimensi menggunakan PCA terbukti membantu menekan gap train-val, classifier head yang bekerja pada fitur berdimensi lebih kecil memiliki ruang yang lebih sempit untuk sekadar menghafal data train. Objective Keras Tuner yang sengaja diarahkan langsung meminimalkan selisih absolut train accuracy dan val accuracy, bukan sekadar val_loss standar, berhasil menemukan kombinasi hyperparameter dengan regularisasi jauh lebih berat, menurunkan gap train-val dari 0.0388 menjadi 0.0244. Model final mencatat test accuracy 0.9381, dengan recall apples 0.98 jauh lebih tinggi dibanding recall tomatoes yang hanya 0.88, pola yang konsisten dengan temuan pada tahap Eksplorasi Visual dimana sebagian gambar tomatoes berwarna kuning dan oranye memiliki kemiripan visual dengan apel. Interpretasi Grad-CAM mengonfirmasi model belajar dari bentuk struktural buah pada kebanyakan sample, meski sempat kebingungan pada beberapa gambar non-buah seperti boneka plush dan ilustrasi kartun yang sengaja dipertahankan di dataset karena deskripsi sumber data tidak mensyaratkan gambar harus berupa foto buah asli.

## Catatan

Dataset asli yang tersedia sangat terbatas, model final hanya dilatih dari 281 gambar asli sebelum augmentasi. Beberapa gambar non-buah seperti spons, ornamen kaca, boneka plush, dan ilustrasi kartun sengaja dipertahankan di dataset karena deskripsi sumber data tidak mensyaratkan gambar harus berupa foto buah asli, meski Grad-CAM menunjukkan gambar semacam ini berpotensi membingungkan model. PCA pada notebook ini di-fit hanya dari data train-fit, sehingga jika dataset diperluas dengan gambar baru di masa depan, PCA perlu di-fit ulang dari awal. Reproducibility hasil training hanya terjamin sempurna selama checkpoint model tetap tersimpan, karena perbedaan hardware maupun sistem operasi berpotensi menghasilkan urutan komputasi floating-point yang sedikit berbeda seandainya seluruh proses benar-benar diulang dari awal tanpa checkpoint yang sudah ada.

## Sumber Data

Dataset Apples or Tomatoes diakses melalui platform Kaggle (https://www.kaggle.com/datasets/samuelcortinhas/apples-or-tomatoes-image-classification), berisi kumpulan gambar hasil web scraping yang tersedia di bawah lisensi CC0 Public Domain. Seluruh isi notebook ini merupakan hasil analisis dan pemodelan orisinal yang dibangun di atas dataset tersebut.