# Prediksi Suhu Harian Delhi Menggunakan Regresi Time Series

Project ini membangun model regresi time series untuk memprediksi suhu rata-rata harian di kota Delhi, India, berdasarkan data cuaca harian dari periode 2013 hingga 2017. Notebook ini menekankan metodologi yang ketat dan jujur, termasuk skema validasi time-based menggunakan TimeSeriesSplit, hyperparameter tuning yang secara eksplisit difokuskan pada regularisasi untuk menekan overfitting, dan pengakuan transparan atas penurunan performa yang terjadi antara data validasi dan data test.

## Tingkat Kesulitan

```
Kompleksitas Data: 7/10
Kompleksitas Modeling: 8/10
Kompleksitas Kode: 8/10
Kedalaman Konsep: 9/10
Overall: 8/10 (Advanced)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model Final | Weighted Average Ensemble (Persistence Model + CatBoost) |
| Bobot Ensemble | Persistence 0.6, CatBoost 0.4 |
| RMSE Validasi | 1.4764 |
| MAE Validasi | 1.1835 |
| R² Validasi | 0.9393 |
| RMSE Test | 1.8758 |
| MAE Test | 1.4497 |
| R² Test | 0.9124 |
| Jumlah Fitur Final | 22 dari 34 fitur hasil VIF |
| Jumlah Algoritma Dibandingkan | 5 (DummyRegressor, Persistence, LightGBM, CatBoost, HistGradientBoosting) |
| Teknik Ensemble Diuji | Weighted Average |

## Struktur Folder

```
DAILY CLIMATE TIME SERIES DATA/
├── checkpoints/
│   ├── baseline_catboost.pkl
│   ├── baseline_dummy.pkl
│   ├── baseline_histgradientboosting.pkl
│   ├── baseline_lightgbm.pkl
│   ├── baseline_persistence.pkl
│   ├── model_final_catboost.pkl
│   ├── tuned_catboost_tuned.pkl
│   ├── tuned_histgradientboosting_tuned.pkl
│   ├── tuned_lightgbm_tuned.pkl
│   ├── tuning_catboost.pkl
│   ├── tuning_histgradientboosting.pkl
│   ├── tuning_lightgbm.pkl
│   └── vif_iterative_result.pkl
├── Daily Climate Dataset/
│   ├── DailyDelhiClimateTest.csv
│   └── DailyDelhiClimateTrain.csv
├── images/
│   ├── acf_pacf_meantemp.png
│   ├── aktual_vs_prediksi_test.png
│   ├── aktual_vs_prediksi_validasi.png
│   ├── boxplot_outlier_train.png
│   ├── evaluasi_model_final_22fitur.png
│   ├── evaluasi_model_final.png
│   ├── evaluasi_model_test.png
│   ├── heatmap_correlation_after_cleaning.png
│   ├── heatmap_correlation_clean.png
│   ├── heatmap_correlation.png
│   ├── residual_test_final.png
│   ├── scatter_features_vs_target.png
│   ├── shap_summary_catboost_full.png
│   ├── shap_summary_catboost.png
│   ├── timeseries_humidity.png
│   ├── timeseries_meanpressure.png
│   ├── timeseries_meantemp.png
│   ├── timeseries_split_visualization.png
│   └── timeseries_wind_speed.png
├── Daily Climate Notebook.ipynb
└── README.md
```

## Tools dan Library

- pandas, numpy — manipulasi dan analisis data
- matplotlib, seaborn — visualisasi
- scikit-learn — TimeSeriesSplit, HistGradientBoostingRegressor, DummyRegressor, metrics
- statsmodels — ACF dan PACF, perhitungan VIF untuk deteksi multikolinearitas
- lightgbm, catboost — algoritma boosting
- optuna — hyperparameter tuning berbasis Bayesian optimization dengan TPE sampler dan pruning
- shap — interpretasi model berbasis SHAP values
- tqdm — progress bar untuk proses training dan tuning
- joblib — penyimpanan checkpoint model dan hasil tuning

## Cara Menjalankan

1. Pastikan Python 3.10 atau lebih baru sudah terinstall di environment Anda
2. Buka `Daily Climate Notebook.ipynb` menggunakan Jupyter Notebook, JupyterLab, atau VS Code
3. Jalankan seluruh cell secara berurutan dari atas ke bawah menggunakan Run All, atau satu per satu untuk mengikuti alur kerja secara bertahap
4. Beberapa cell akan otomatis menginstall package tambahan yang dibutuhkan (lightgbm, catboost, tqdm, statsmodels, optuna, shap)
5. Proses hyperparameter tuning dan perbandingan model menggunakan checkpoint yang tersimpan di folder `checkpoints/`, sehingga menjalankan ulang notebook tidak akan mengulang proses yang memakan waktu lama. Hapus file checkpoint terkait jika ingin menjalankan ulang proses tersebut dari awal
6. Seluruh visualisasi akan tersimpan otomatis ke folder `images/`

## Alur Kerja

1. **Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan, membuat folder untuk menyimpan visualisasi dan checkpoint, serta memuat dataset cuaca harian Delhi

2. **Data Quality Check** - memeriksa duplikat, tipe data, missing value, statistik deskriptif, outlier, serta konsistensi rentang nilai tiap kolom

3. **Eksplorasi Data (EDA)** - memahami pola musiman tiap fitur, korelasi antar fitur, hubungan fitur terhadap target, serta autokorelasi target melalui ACF dan PACF

4. **Split Data untuk Training dan Validasi** - membagi data secara kronologis menggunakan TimeSeriesSplit lima fold, dengan fold terakhir sebagai validasi resmi dan test set yang disisihkan sepenuhnya

5. **Data Cleaning** - menangani outlier ekstrem pada meanpressure menggunakan capping berbasis rentang fisik wajar tekanan udara

6. **Feature Engineering dan Feature Selection (VIF)** - membuat fitur lag, rolling window, dan kalender siklikal, kemudian menyaring fitur redundant menggunakan VIF iteratif

7. **Modeling Baseline** - membandingkan DummyRegressor, Persistence Model, dan tiga model gradient boosting sebagai baseline menggunakan parameter default

8. **Hyperparameter Tuning** - mencari kombinasi parameter terbaik menggunakan Optuna dengan fokus regularisasi ketat untuk menekan overfitting

9. **Ensemble Model** - membandingkan seluruh kombinasi model tunggal, berpasangan, triple, dan gabungan menggunakan weighted average, diverifikasi dengan bootstrap

10. **Evaluasi Model** - menilai performa model final menggunakan RMSE, MAE, R², scatter plot prediksi vs aktual, dan residual plot

11. **Interpretasi Model (SHAP)** - menjelaskan kontribusi tiap fitur terhadap prediksi menggunakan SHAP beeswarm plot

12. **Eksperimen Feature Selection** - menguji apakah fitur dengan kontribusi SHAP nol dapat dihapus tanpa mengorbankan performa

13. **Retrain Model Final** - melatih ulang model final menggunakan seluruh data training yang tersedia

14. **Prediksi Final** - mengevaluasi model final pada data test yang belum pernah dilihat sepanjang notebook

15. **Kesimpulan** - merangkum model final, performa, fitur paling berpengaruh, serta kendala dan pembelajaran sepanjang proses pengembangan

## Temuan Utama

Salah satu temuan paling signifikan pada notebook ini adalah ketiga model gradient boosting dengan parameter default ternyata overfit parah dan kalah dari Persistence Model, baseline naif yang hanya mengandalkan nilai suhu hari sebelumnya, mendorong proses hyperparameter tuning yang secara eksplisit difokuskan pada regularisasi ketat menggunakan objective function yang menghukum gap antara train dan validation. Meski gap berhasil ditekan signifikan setelah tuning, hasil akhir tetap menunjukkan bahwa kombinasi Persistence Model dengan CatBoost yang telah diregularisasi ketat, dengan bobot 0.6 dan 0.4, mengungguli seluruh model tunggal maupun kombinasi lain yang lebih kompleks, dibuktikan melalui bootstrap resampling yang menunjukkan win rate 65.3%. Interpretasi menggunakan SHAP mengonfirmasi meanpressure dan turunannya sebagai fitur paling berpengaruh, diikuti month_cos dan humidity, sementara seluruh fitur turunan wind_speed terbukti nyaris tidak berkontribusi dan berhasil dihapus tanpa mengorbankan performa, menyisakan 22 dari 34 fitur hasil seleksi VIF. RMSE pada data validasi tercatat 1.4764 dengan R² sebesar 0.9393, sementara RMSE pada data test yang belum pernah disentuh sepanjang proses pengembangan tercatat 1.8758 dengan R² sebesar 0.9124, penurunan yang setelah ditelusuri melalui diagnosa residual per tanggal teridentifikasi berasal dari perbedaan karakteristik musiman antara periode validasi dan test, bukan dari anomali atau kesalahan teknis.

## Catatan

Data test hanya mencakup periode Januari hingga April 2017, sehingga tidak merepresentasikan siklus musiman penuh selama satu tahun, dan performa model pada musim lain di luar rentang tersebut belum teruji secara langsung. Model final sangat bergantung pada meanpressure sebagai fitur paling berpengaruh, kolom yang pada data mentah justru memiliki kualitas paling bermasalah di antara seluruh fitur, sehingga performa model ke depan akan sensitif terhadap kualitas pengukuran tekanan udara pada data baru. Eksperimen ensemble pada notebook ini hanya menggunakan teknik weighted average, tanpa mencoba Stacking sebagai pembanding tambahan, sehingga tidak dapat dipastikan apakah teknik ensemble lain berpotensi menghasilkan performa yang lebih baik. Penurunan performa dari data validasi ke data test, meski telah ditelusuri dan tidak menunjukkan pola anomali sistematis, tetap mengindikasikan bahwa estimasi performa pada data validasi sedikit terlalu optimis dibanding kondisi generalisasi yang sesungguhnya.

## Sumber Data

Dataset yang digunakan adalah Daily Climate Time Series Data, berisi data cuaca harian kota Delhi, India dari 1 Januari 2013 hingga 24 April 2017, tersedia di https://www.kaggle.com/datasets/sumanthvrao/daily-climate-time-series-data. Dataset ini dilisensikan di bawah CC0: Public Domain, tersedia di https://creativecommons.org/publicdomain/zero/1.0/.