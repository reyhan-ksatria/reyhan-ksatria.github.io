# Klasifikasi Fake News pada Artikel Berbahasa Inggris Menggunakan Deep Neural Network

Project ini membangun model klasifikasi teks biner untuk mengklasifikasikan artikel berita ke dalam dua kelas yaitu Fake dan True, berdasarkan 24.353 artikel data training, 8.117 artikel data evaluasi, dan 8.117 artikel data test berbahasa Inggris. Notebook ini menekankan deteksi dan pembersihan kebocoran data melalui pola sumber berita, pembangunan Deep Neural Network (DNN) dengan Embedding layer trainable, hyperparameter tuning menggunakan Optuna dengan reproducibility penuh, serta interpretasi model menggunakan LIME.

## Tingkat Kesulitan

```
Kompleksitas Data: 6/10
Kompleksitas Modeling: 6/10
Kompleksitas Kode: 7/10
Kedalaman Konsep: 7/10
Overall: 6.5/10 (Intermediate)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model Final | Deep Neural Network (Embedding + GlobalAveragePooling1D + Dense) |
| Test Accuracy (Model Final) | 0.98 |
| Validation Accuracy sebelum Tuning | 0.9696 |
| Validation Accuracy setelah Tuning | 0.9745 |
| Gap Train-Validasi (Model Tuned) | 0.0172 |
| Vocabulary Size | 20.000 kata |
| Panjang Maksimum Sequence | 500 kata |
| Jumlah Parameter Model Baseline | 1.286.273 |
| Metode Tuning | Optuna dengan TPESampler |
| Jumlah Trial Hyperparameter Tuning | 30 |

## Struktur Folder

```
FAKE NEWS CLASSIFICATION/
├── checkpoints/
│   ├── best_optuna_params.joblib
│   ├── best_optuna_trial_info.joblib
│   ├── dnn_final_model.keras
│   ├── dnn_history.pkl
│   ├── dnn_model.keras
│   ├── dnn_tuned_history.pkl
│   ├── dnn_tuned_model.keras
│   └── tokenizer.pkl
├── Fake News Dataset/
│   ├── evaluation.csv
│   ├── test (1).csv
│   └── train (2).csv
├── images/
│   ├── confusion_matrix_final.png
│   ├── confusion_matrix_test.png
│   ├── confusion_matrix_tuned.png
│   ├── distribusi_label.png
│   ├── distribusi_text_len.png
│   ├── learning_curve_after_tuning.png
│   ├── learning_curve_baseline_dnn.png
│   ├── learning_curve_before_tuning.png
│   ├── learning_curve_tuned_dnn.png
│   ├── pola_leakage_reuters_caps.png
│   └── top_kata_per_label.png
├── README.md
└── Fake News Notebook.ipynb
```

## Tools dan Library

- pandas, numpy — manipulasi dan analisis data
- matplotlib, seaborn — visualisasi
- tensorflow, keras — pembangunan dan training Deep Neural Network
- scikit-learn — CountVectorizer, metrics evaluasi
- optuna — hyperparameter tuning dengan TPESampler yang dikunci demi reproducibility
- lime — interpretasi model berbasis LIME pada teks
- joblib, pickle — penyimpanan checkpoint model dan hasil eksperimen

## Cara Menjalankan

1. Pastikan Python 3.10 atau lebih baru sudah terinstall di environment Anda
2. Buka `Fake News Notebook.ipynb` menggunakan Jupyter Notebook, JupyterLab, atau VS Code
3. Jalankan seluruh cell secara berurutan dari atas ke bawah menggunakan Run All, atau satu per satu untuk mengikuti alur kerja secara bertahap
4. Beberapa cell akan otomatis menginstall package tambahan yang dibutuhkan (tensorflow, scikit-learn, optuna, lime)
5. Proses training baseline, hyperparameter tuning, dan training model final menggunakan checkpoint yang tersimpan di folder `checkpoints/`, sehingga menjalankan ulang notebook tidak akan mengulang proses yang memakan waktu lama. Hapus file checkpoint terkait jika ingin menjalankan ulang proses tersebut dari awal
6. Seluruh visualisasi akan tersimpan otomatis ke folder `images/`

## Alur Kerja

1. **Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan termasuk TensorFlow, mengatur reproducibility lewat penguncian random seed dan mode deterministic, membuat folder untuk menyimpan visualisasi dan checkpoint, serta memuat ketiga split dataset resmi

2. **Data Quality Check** - memeriksa duplikat, tipe data, missing value, baris dengan text kosong atau sangat pendek, serta title placeholder pada ketiga split dataset

3. **Eksplorasi Data (EDA)** - memahami distribusi label, distribusi panjang text dan jumlah kata per label, pola byline sumber berita Reuters sebagai indikasi kebocoran data, rasio huruf kapital pada title, serta kata-kata paling sering muncul pada masing-masing kelas

4. **Split Data untuk Training dan Validasi** - mendefinisikan fitur dan target dari ketiga split resmi dataset yang telah disediakan sumber data

5. **Text Cleaning** - membersihkan data dari duplikat, baris text kosong, title placeholder, serta menghapus pola byline dan seluruh kemunculan kata 'Reuters' sebelum title dan text digabungkan menjadi satu kolom

6. **Tokenisasi dan Padding** - mengubah teks menjadi representasi sequence angka menggunakan Tokenizer, dilanjutkan proses padding agar seluruh sequence memiliki panjang yang seragam

7. **Modeling** - melatih baseline DummyClassifier dan model Deep Neural Network dengan Embedding layer trainable, GlobalAveragePooling, serta Dense layer sebagai model utama

8. **Hyperparameter Tuning** - mengoptimalkan parameter model menggunakan Optuna dengan TPESampler yang dikunci demi reproducibility, dibandingkan langsung terhadap performa baseline

9. **Evaluasi Model** - memeriksa classification report dan confusion matrix dari model tuned pada data validasi maupun data test

10. **Interpretasi Model** - menganalisis kontribusi kata terhadap prediksi model menggunakan LIME pada contoh artikel Fake dan True

11. **Retrain Model Final** - melatih ulang model final menggunakan seluruh data yang tersedia, gabungan training dan validasi

12. **Kesimpulan** - merangkum model final, skor metrik utama, temuan interpretasi, serta keterbatasan yang ditemukan sepanjang proses

## Temuan Utama

Tahap EDA menemukan pola kebocoran data yang signifikan melalui kata 'Reuters', hampir seluruh artikel berlabel True mengandung kata tersebut sementara artikel Fake nyaris tidak pernah mengandungnya, sehingga pola byline dan seluruh kemunculan kata tersebut dibersihkan sebelum tokenisasi. Hyperparameter tuning menggunakan Optuna berhasil menaikkan validation accuracy dari 0.9696 pada baseline menjadi 0.9745, dengan dropout rate yang jauh lebih tinggi dibanding baseline menunjukkan tuner condong memilih regularisasi yang lebih kuat. Model final yang dilatih ulang menggunakan gabungan data train dan eval mencatat accuracy sebesar 0.98 pada test set, dengan recall kelas True yang meningkat dibanding model tuned sebelum digabung data eval. Interpretasi menggunakan LIME menunjukkan model cenderung mengandalkan kata fungsi yang sering berulang pada contoh artikel Fake, sementara pada contoh artikel True beberapa kata konten yang relevan seperti 'Senate' dan 'said' turut berkontribusi, mengindikasikan karakteristik arsitektur GlobalAveragePooling1D yang merata-ratakan seluruh embedding kata perlu dipahami sebagai bagian dari cara kerja model ini.

## Catatan

Interpretasi menggunakan LIME pada notebook ini hanya mewakili satu contoh artikel Fake dan satu contoh artikel True, sehingga pola kata fungsi yang dominan pada contoh Fake tidak dapat digeneralisasi sebagai perilaku model secara keseluruhan tanpa pengujian pada sampel yang lebih banyak. Arsitektur GlobalAveragePooling1D yang digunakan berpotensi membuat kata yang sering berulang dalam satu dokumen memengaruhi rata-rata embedding secara signifikan terlepas dari makna semantiknya, sebuah karakteristik yang belum diuji lebih lanjut apakah benar memengaruhi kualitas prediksi atau sekadar cara kerja model yang tetap menghasilkan performa tinggi. Dataset ini merupakan gabungan dari beberapa dataset fake news di Kaggle dengan mayoritas artikel True bersumber dari Reuters, sehingga model berpotensi kurang general terhadap artikel True dari sumber berita lain yang gaya penulisannya berbeda dari kantor berita tersebut.

## Sumber Data

Dataset yang digunakan adalah Fake News Classification, disusun oleh Aadya Singh dan tersedia di Kaggle pada https://www.kaggle.com/datasets/aadyasingh55/fake-news-classification, dengan lisensi Apache License 2.0. Dataset ini merupakan gabungan dari beberapa dataset fake news, terdiri dari tiga file CSV yaitu train, test, dan evaluation.