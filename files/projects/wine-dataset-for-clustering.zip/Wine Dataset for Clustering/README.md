# Wine Clustering - Pengelompokan Wine Berdasarkan Komposisi Kimia

Notebook ini mengelompokkan 178 sampel wine ke dalam tiga cluster berdasarkan 13 atribut kimia, tanpa label cultivar asli karena data ini sengaja diadaptasi dari UCI Wine Dataset untuk keperluan unsupervised learning. Alur mencakup pengecekan kualitas data, eksplorasi data, penentuan jumlah cluster optimal, perbandingan empat algoritma clustering, eksperimen ensemble berbobot, hingga feature selection, dengan setiap keputusan besar diuji terlebih dahulu menggunakan bukti kuantitatif sebelum diputuskan.

## Tingkat Kesulitan

```
Kompleksitas Data: 4/10
Kompleksitas Modeling: 6/10
Kompleksitas Kode: 7/10
Kedalaman Konsep: 8/10
Overall: 6.25/10 (Intermediate)
```

## Ringkasan Hasil

| Aspek | Detail |
|---|---|
| Model final | Spectral Clustering (k = 3), Silhouette Score 0.2851 |
| Jumlah cluster | 3, konsisten dari Elbow Method, Silhouette Analysis, dan Gap Statistic |
| Jumlah sampel | 178 |
| Jumlah fitur | 13, seluruhnya numerik |
| Algoritma dibandingkan | 4 algoritma (K-Means, Agglomerative, GMM, Spectral Clustering) |
| Ensemble/Consensus Clustering | 15 kombinasi diuji, tidak ada yang mengungguli Spectral Clustering tunggal |
| Fitur paling berpengaruh | Proline, Flavanoids, Color_Intensity, Alcohol, OD280 |

## Struktur Folder

```
WINE DATASET FOR CLUSTERING/
├── checkpoints/
│   ├── bootstrap_capping_results.pkl
│   └── ensemble_weighted_results.pkl
├── images/
│   ├── boxplot_outlier_check.png
│   ├── boxplot_profil_cluster.png
│   ├── distribusi_fitur.png
│   ├── elbow_silhouette.png
│   ├── feature_importance_surrogate.png
│   ├── gap_statistic.png
│   ├── heatmap_korelasi.png
│   ├── pca_2d_perbandingan_model.png
│   ├── pca_3d_perbandingan_model.png
│   └── pca_explained_variance.png
├── Wine Dataset/
│   └── wine-clustering.csv
├── README.md
└── Wine Clustering Notebook.ipynb
```

## Tools dan Library

- pandas, numpy
- matplotlib, seaborn
- scikit-learn (KMeans, AgglomerativeClustering, GaussianMixture, SpectralClustering, RandomForestClassifier, StandardScaler, PCA, silhouette_score, davies_bouldin_score, calinski_harabasz_score, adjusted_rand_score)
- scipy (linkage, fcluster, squareform)
- optuna
- tqdm, joblib

## Cara Menjalankan

1. Pastikan seluruh library pada daftar Tools dan Library sudah terinstal. Optuna diinstal otomatis melalui cell notebook saat pertama kali dijalankan, sehingga tidak perlu instalasi manual terpisah.
2. Letakkan folder Wine Dataset beserta isinya pada direktori yang sama dengan notebook.
3. Buka Wine Clustering Notebook.ipynb, jalankan seluruh cell secara berurutan dari atas menggunakan Run All.
4. Seluruh visualisasi akan otomatis tersimpan ke folder images, sementara hasil proses yang memakan waktu, seperti uji bootstrap dan pencarian bobot ensemble, tersimpan ke folder checkpoints agar tidak perlu dihitung ulang pada eksekusi berikutnya.

## Alur Kerja

**1. Import Library dan Load Dataset** - menyiapkan library yang dibutuhkan, membuat folder images dan checkpoints, serta memuat dataset wine

**2. Data Quality Check** - memeriksa duplikat, tipe data, missing value, kardinalitas kolom, statistik deskriptif, dan outlier

**3. Eksplorasi Data (EDA)** - memahami distribusi tiap fitur, korelasi antar fitur, serta dimensionalitas efektif data melalui analisis PCA

**4. Preprocessing** - scaling seluruh fitur numerik menggunakan StandardScaler

**5. Penentuan Jumlah Cluster Optimal** - mencari jumlah cluster menggunakan Elbow Method, Silhouette Analysis, dan Gap Statistic

**6. Modeling** - menjalankan dan membandingkan algoritma K-Means, Agglomerative Clustering, Gaussian Mixture Model, dan Spectral Clustering, masing-masing disertai pencarian parameter terbaik, dilengkapi eksperimen penanganan outlier

**7. Evaluasi dan Perbandingan Model** - menghitung Silhouette Score, Davies-Bouldin Index, dan Calinski-Harabasz Index untuk seluruh model, dilengkapi visualisasi PCA 2D dan 3D

**8. Ensemble/Consensus Clustering** - menggabungkan beberapa model melalui co-association matrix dengan bobot dicari menggunakan Optuna, dibandingkan terhadap seluruh model tunggal dalam satu ranking

**9. Profiling dan Interpretasi Cluster** - membentuk profil karakteristik tiap cluster, menghitung feature importance menggunakan surrogate classifier, serta menguji dampak feature selection

**10. Kesimpulan** - merangkum temuan utama, kendala, keterbatasan, serta arahan eksplorasi lebih lanjut

Tahap Split Data untuk Training dan Validasi serta Prediksi Final dan Submission dilewati karena project ini bersifat clustering murni tanpa target prediktif, sehingga alur kerja menyesuaikan konteks unsupervised, bukan mengikuti pola supervised konvensional.

## Temuan Utama

Spectral Clustering terpilih sebagai model final setelah dibandingkan secara ketat terhadap tiga algoritma lain dan seluruh 15 kombinasi ensemble berbobot, yang terbukti tidak memberikan perbaikan apapun karena hanya mereproduksi partisi model dominan dalam tiap kombinasi. Ketiga cluster yang terbentuk menunjukkan karakteristik kimia yang berbeda secara jelas, dengan Proline, Flavanoids, Color_Intensity, Alcohol, dan OD280 sebagai fitur paling berpengaruh, sejalan dengan pengetahuan historis bahwa dataset ini berasal dari tiga cultivar wine berbeda meski labelnya telah dihapus. Eksperimen feature selection mengungkap temuan penting, yaitu Silhouette Score naik konsisten dari 0.2851 menjadi 0.4755 seiring bertambahnya fitur yang dihapus, namun kenaikan ini merupakan konsekuensi matematis dari berkurangnya dimensi data, bukan perbaikan struktur cluster yang sesungguhnya, sehingga seluruh 13 fitur tetap dipertahankan pada model final.

## Catatan

Dataset ini tidak memiliki label cultivar asli untuk validasi eksternal, sehingga seluruh evaluasi bergantung sepenuhnya pada metrik internal yang mengukur kekompakan dan pemisahan cluster, bukan kebenaran struktur terhadap kelompok yang sesungguhnya. Visualisasi PCA 2D dan 3D masing-masing hanya merepresentasikan 55.41% dan 66.53% variansi data, sehingga sebagian pola yang terlihat pada gambar dapat berbeda dari struktur sesungguhnya pada 13 dimensi asli. Penanganan outlier menggunakan capping diuji secara eksperimental dan terbukti tidak signifikan secara statistik pada seluruh model melalui uji bootstrap, sehingga tidak diterapkan pada model final.

## Sumber Data

Dataset Wine Dataset for Clustering diakses melalui platform Kaggle: https://www.kaggle.com/datasets/harrywang/wine-dataset-for-clustering, merupakan adaptasi dari Wine Data Set pada UCI Machine Learning Repository: https://archive.ics.uci.edu/dataset/109/wine dengan label jenis wine dihapus untuk keperluan unsupervised learning. Data asli merupakan hasil analisis kimia wine yang ditanam pada region yang sama di Italia namun berasal dari tiga cultivar berbeda.

Lisensi: Pada halaman Kaggle, lisensi dataset tertulis "Data files © Original Authors", tanpa rincian lebih lanjut soal syarat penggunaan. Dataset sumber pada UCI Machine Learning Repository mencantumkan lisensi Creative Commons Attribution 4.0 International (CC BY 4.0), namun ini merupakan keterangan pada halaman UCI, bukan keterangan yang tertulis langsung pada halaman Kaggle. Catatan ini bukan nasihat hukum, sebelum digunakan untuk tujuan komersial, disarankan memeriksa dan mengonfirmasi langsung syarat lisensi pada kedua tautan sumber di atas.